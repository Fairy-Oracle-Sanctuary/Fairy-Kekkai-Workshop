# ocr_service.py

import os

from PySide6.QtCore import QObject, QProcess, Signal

from ..common.config import cfg
from ..common.event_bus import event_bus
from ..common.logger import Logger


class OCRTask:
    """OCR任务类"""

    _id_counter = 0

    def __init__(self, args):
        self.args = args
        self.status = "等待中"  # 等待中, 处理中, 已完成, 失败
        self.progress = 0
        self.error_message = ""
        self.input_file = args.get("video_path")
        self.output_file = args.get("file_path")
        self.temp_dir = args.get("temp_dir")

        OCRTask._id_counter += 1
        self.id = OCRTask._id_counter


class OCRProcess(QObject):
    """OCR处理进程"""

    progress_signal = Signal(int, int, int)  # 进度百分比, 当前帧, 总帧数
    finished_signal = Signal(bool, str)  # 成功/失败, 消息
    log_signal = Signal(str, bool, bool)  # 日志信息
    print_signal = Signal(str)  # 捕获print输出
    cancelled_signal = Signal()  # 取消完成信号

    def __init__(self, task: OCRTask):
        super().__init__()
        self.logger = Logger("OCRProcess", "videocr")
        self.task = task
        self.is_cancelled = False
        self.process = None
        self.output_lines = []  # 存储输出用于错误诊断
        self._cancellation_timer = None

    def __del__(self):
        """析构时确保子进程被终止"""
        if self.process and self.process.state() == QProcess.Running:
            self.process.kill()
            self.process.waitForFinished(1000)

    @staticmethod
    def _activate_as_current(output_file: str):
        """将提取结果复制为 原文.srt（作为当前活动原文）"""
        import shutil

        parent_dir = os.path.dirname(output_file)
        current_file = os.path.join(parent_dir, "原文.srt")
        try:
            if os.path.exists(output_file) and os.path.getsize(output_file) > 0:
                shutil.copy2(output_file, current_file)
        except Exception:
            pass

    def build_ocr_command(self):
        """根据配置构建 ocr 命令"""
        args = self.task.args

        cmd_path = cfg.get(cfg.videocrCliPath)

        # 构建命令参数
        cmd_args = []

        # 添加参数
        cmd_args.extend(["--video_path", args["video_path"]])
        cmd_args.extend(["--output", args["file_path"]])
        cmd_args.extend(["--temp_dir", args["temp_dir"]])
        cmd_args.extend(["--lang", args["lang"]])
        cmd_args.extend(["--time_start", args["time_start"]])
        if args["time_end"]:
            cmd_args.extend(["--time_end", args["time_end"]])
        cmd_args.extend(["--sim_threshold", str(args["sim_threshold"])])
        cmd_args.extend(["--max_merge_gap", str(args["max_merge_gap_sec"])])
        cmd_args.extend(["--use_fullframe", str(args["use_fullframe"]).lower()])
        cmd_args.extend(["--use_gpu", str(args["use_gpu"]).lower()])
        cmd_args.extend(["--use_angle_cls", str(args["use_angle_cls"]).lower()])
        cmd_args.extend(["--use_server_model", str(args["use_server_model"]).lower()])
        cmd_args.extend(["--ssim_threshold", str(args["ssim_threshold"])])
        cmd_args.extend(["--subtitle_position", args["subtitle_position"]])
        cmd_args.extend(["--frames_to_skip", str(args["frames_to_skip"])])
        cmd_args.extend(["--ocr_image_max_width", str(args["ocr_image_max_width"])])
        cmd_args.extend(["--post_processing", str(args["post_processing"]).lower()])
        cmd_args.extend(
            ["--min_subtitle_duration", str(args["min_subtitle_duration_sec"])]
        )

        # 处理paddleocr_path参数
        if "paddleocr_path" in args and args["paddleocr_path"]:
            cmd_args.extend(["--paddleocr_path", args["paddleocr_path"]])

        # 处理supportFilesPath参数
        if "supportFilesPath" in args and args["supportFilesPath"]:
            cmd_args.extend(["--supportFilesPath", args["supportFilesPath"]])

        # 处理use_dual_zone参数
        if args["use_dual_zone"]:
            cmd_args.extend(["--use_dual_zone", str(args["use_dual_zone"]).lower()])

        # 处理crop_zones参数
        cmd_args.extend(["--crop_x", str(args["--crop_x"])])
        cmd_args.extend(["--crop_y", str(args["--crop_y"])])
        cmd_args.extend(["--crop_width", str(args["--crop_width"])])
        cmd_args.extend(["--crop_height", str(args["--crop_height"])])
        if args["use_dual_zone"]:
            cmd_args.extend(["--crop_x2", str(args["--crop_x2"])])
            cmd_args.extend(["--crop_y2", str(args["--crop_y2"])])
            cmd_args.extend(["--crop_width2", str(args["--crop_width2"])])
            cmd_args.extend(["--crop_height2", str(args["--crop_height2"])])

        return cmd_path, cmd_args

    def start(self):
        """启动OCR处理进程"""
        self.task.status = "提取中"

        try:
            # 清理临时目录
            if self.task.temp_dir and os.path.exists(self.task.temp_dir):
                import shutil

                try:
                    shutil.rmtree(self.task.temp_dir)
                    self.log_signal.emit(
                        f"已清理临时目录: {self.task.temp_dir}\n", False, False
                    )
                except Exception as e:
                    self.log_signal.emit(f"清理临时目录失败: {str(e)}\n", True, False)

            # 获取videocr-cli.exe路径
            cmd_path, cmd_args = self.build_ocr_command()

            if not os.path.exists(cmd_path):
                error_msg = f"videocr-cli.exe不存在: {cmd_path}"
                self.task.status = "失败"
                self.task.error_message = error_msg
                self.finished_signal.emit(False, error_msg)
                event_bus.ocr_finished_signal.emit(False, error_msg)
                return

            # 确保输出目录存在
            output_dir = os.path.dirname(self.task.output_file)
            if output_dir:
                os.makedirs(output_dir, exist_ok=True)

            print(f"执行OCR命令: {cmd_path} {' '.join(cmd_args)}")

            # 创建QProcess
            self.process = QProcess()

            # 合并 stdout 和 stderr 到一个通道，确保所有输出都能被实时捕获
            self.process.setProcessChannelMode(QProcess.MergedChannels)

            # 连接信号
            self.process.readyReadStandardOutput.connect(self.handle_stdout)
            self.process.finished.connect(self.handle_finished)
            self.process.errorOccurred.connect(self.handle_error)

            # 设置程序和参数
            self.process.setProgram(cmd_path)
            self.process.setArguments(cmd_args)

            # 启动进程
            self.process.start()

        except Exception as e:
            if not self.is_cancelled:
                error_msg = f"OCR处理失败: {str(e)}"
                print(error_msg)
                self.task.status = "失败"
                self.task.error_message = error_msg
                self.finished_signal.emit(False, error_msg)
                event_bus.ocr_finished_signal.emit(False, error_msg)
                self.logger.error(
                    f"OCR处理失败: -{self.task.input_file}- 错误信息: {str(e)}"
                )

    def handle_stdout(self):
        """处理标准输出"""
        if not self.process:
            return

        data = (
            self.process.readAllStandardOutput().data().decode("utf-8", errors="ignore")
        )
        lines = data.replace("\r\n", "\n").replace("\r", "\n").split("\n")

        for line in lines:
            line = line.strip()
            if not line:
                continue

            self.output_lines.append(line)

            # 如果已取消，不再发送print信号
            if self.is_cancelled:
                continue

            # 发射print信号，由videocr_task_interface.py中的onPrintOutput处理
            self.print_signal.emit(line)

    def handle_stderr(self):
        """处理标准错误"""
        if not self.process:
            return

        data = (
            self.process.readAllStandardError().data().decode("utf-8", errors="ignore")
        )
        lines = data.replace("\r\n", "\n").replace("\r", "\n").split("\n")

        for line in lines:
            line = line.strip()
            if not line:
                continue

            self.output_lines.append(line)

            # 如果已取消，不再发送print信号
            if self.is_cancelled:
                continue

            # 发射print信号，由videocr_task_interface.py中的onPrintOutput处理
            self.print_signal.emit(line)

    def handle_finished(self, exit_code, exit_status):
        """进程完成处理"""
        if self.is_cancelled:
            self.task.status = "已取消"
            self.finished_signal.emit(False, "OCR处理已取消")
            self.cancelled_signal.emit()
            self.logger.info(f"OCR处理已取消: -{self.task.input_file}-")
        elif exit_code == 0:
            self.task.status = "已完成"
            self.task.progress = 100

            # 检查输出文件是否存在
            if os.path.exists(self.task.output_file):
                file_size = os.path.getsize(self.task.output_file) / (1024 * 1024)  # MB
                success_msg = f"OCR处理完成 - 文件大小: {file_size:.2f}MB"
            else:
                success_msg = "OCR处理完成"

            # 自动复制到 原文.srt（设为当前活动原文）
            self._activate_as_current(self.task.output_file)

            self.finished_signal.emit(True, success_msg)
            self.log_signal.emit("OCR处理完成\n", False, False)
            event_bus.ocr_finished_signal.emit(True, str(self.task.output_file))
            self.logger.info(
                f"OCR处理完成: -{self.task.input_file}- 输出文件: {self.task.output_file}"
            )
        else:
            error_message = f"OCR处理失败，错误码: {exit_code}"

            # 添加最后几行输出作为调试信息
            if self.output_lines:
                last_lines = "\n".join(self.output_lines[-5:])
                error_message += f"\n最后输出:\n{last_lines}"

            self.task.status = "失败"
            self.task.error_message = error_message
            self.finished_signal.emit(False, error_message)
            self.log_signal.emit(f"OCR处理失败:\n{error_message}\n", False, False)
            event_bus.ocr_finished_signal.emit(False, error_message)
            self.logger.error(
                f"OCR处理失败: -{self.task.input_file}- 错误信息: {error_message}"
            )

    def handle_error(self, error):
        """处理进程错误"""
        if self.is_cancelled:
            return

        error_map = {
            QProcess.FailedToStart: "进程启动失败",
            QProcess.Crashed: "进程崩溃",
            QProcess.Timedout: "进程超时",
            QProcess.WriteError: "写入错误",
            QProcess.ReadError: "读取错误",
            QProcess.UnknownError: "未知错误",
        }

        error_msg = error_map.get(error, f"进程错误: {error}")
        self.finished_signal.emit(False, error_msg)

    def cancel(self):
        """取消OCR处理 - 异步非阻塞版本"""
        if self.is_cancelled:
            return

        self.is_cancelled = True

        # 立即发送取消日志，不等待进程结束
        self.log_signal.emit("正在取消OCR处理...\n", False, False)

        if self.process and self.process.state() == QProcess.Running:
            # 获取进程ID
            pid = self.process.processId()

            # 使用taskkill强制终止进程树（包括子进程）
            import subprocess

            try:
                subprocess.run(
                    ["taskkill", "/F", "/T", "/PID", str(pid)],
                    capture_output=True,
                    timeout=2,
                )
                self.log_signal.emit("已强制终止OCR进程及其子进程", False, False)
            except Exception as e:
                self.log_signal.emit(f"终止进程失败: {str(e)}", True, False)
                # 如果taskkill失败，尝试使用QProcess的kill
                self.process.kill()

            # 等待进程结束
            if self.process.waitForFinished(2000):
                self.cancelled_signal.emit()
            else:
                self.cancelled_signal.emit()
        else:
            # 如果没有进程在运行，直接发送取消完成信号
            self.cancelled_signal.emit()
