# coding:utf-8
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QHBoxLayout, QLabel, QVBoxLayout, QWidget
from qfluentwidgets import (
    CardWidget,
    FlowLayout,
    IconWidget,
    TextWrap,
)

from ..common.event_bus import event_bus
from ..common.style_sheet import StyleSheet


class BaseSampleCard(CardWidget):
    def __init__(self, icon, title, content, parent=None):
        super().__init__(parent=parent)

        self.iconWidget = IconWidget(icon, self)
        self.titleLabel = QLabel(title, self)
        self.contentLabel = QLabel(TextWrap.wrap(content, 45, False)[0], self)

        self.hBoxLayout = QHBoxLayout(self)
        self.vBoxLayout = QVBoxLayout()

        self.setFixedSize(360, 90)
        self.iconWidget.setFixedSize(48, 48)

        self.hBoxLayout.setSpacing(28)
        self.hBoxLayout.setContentsMargins(20, 0, 0, 0)
        self.vBoxLayout.setSpacing(2)
        self.vBoxLayout.setContentsMargins(0, 0, 0, 0)
        self.vBoxLayout.setAlignment(Qt.AlignVCenter)

        self.hBoxLayout.setAlignment(Qt.AlignVCenter)
        self.hBoxLayout.addWidget(self.iconWidget)
        self.hBoxLayout.addLayout(self.vBoxLayout)
        self.vBoxLayout.addStretch(1)
        self.vBoxLayout.addWidget(self.titleLabel)
        self.vBoxLayout.addWidget(self.contentLabel)
        self.vBoxLayout.addStretch(1)

        self.titleLabel.setObjectName("titleLabel")
        self.contentLabel.setObjectName("contentLabel")


class SwitchSampleCard(BaseSampleCard):
    """Sample card"""

    def __init__(self, icon, title, content, routeKey, index, parent=None):
        super().__init__(icon, title, content, parent)
        self.index = index
        self.routekey = routeKey

    def mouseReleaseEvent(self, e):
        super().mouseReleaseEvent(e)
        event_bus.switchToSampleCard.emit(self.routekey, self.index)


class OpenUrlSampleCard(BaseSampleCard):
    """Sample card"""

    def __init__(self, icon, title, content, url, parent=None):
        super().__init__(icon, title, content, parent)
        self.url = url

    def mouseReleaseEvent(self, e):
        super().mouseReleaseEvent(e)
        event_bus.openUrl.emit(self.url)


class SampleCardView(QWidget):
    """Sample card view"""

    def __init__(self, title: str, parent=None):
        super().__init__(parent=parent)
        self.titleLabel = QLabel(title, self)
        self.vBoxLayout = QVBoxLayout(self)
        self.flowLayout = FlowLayout()

        self.vBoxLayout.setContentsMargins(36, 0, 36, 0)
        self.vBoxLayout.setSpacing(10)
        self.flowLayout.setContentsMargins(0, 0, 0, 0)
        self.flowLayout.setHorizontalSpacing(12)
        self.flowLayout.setVerticalSpacing(12)

        self.vBoxLayout.addWidget(self.titleLabel)
        self.vBoxLayout.addLayout(self.flowLayout, 1)

        self.titleLabel.setObjectName("viewTitleLabel")
        StyleSheet.SAMPLE_CARD.apply(self)

    def addSampleCard(self, icon, title, content, routeKey, index):
        """add sample card"""
        card = SwitchSampleCard(icon, title, content, routeKey, index, parent=self)
        self.flowLayout.addWidget(card)

    def addOpenUrlCard(self, icon, title, content, url):
        """add url sample"""
        card = OpenUrlSampleCard(icon, title, content, url, parent=self)
        self.flowLayout.addWidget(card)
        card.setToolTip(url)
